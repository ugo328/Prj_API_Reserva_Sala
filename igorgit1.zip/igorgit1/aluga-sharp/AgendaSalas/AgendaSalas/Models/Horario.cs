﻿using System.ComponentModel.DataAnnotations;
namespace AgendaSalas.Models
{
    public class Horario
    {
        public static void main(String[] arg)
        {
            DateTime inicio = DateTime.Now;
            DateTime final = DateTime.Now;
        }
        [Key]
        public int HorarioId { get; set; }

        public DateTime Inicio { get; set; }

        public DateTime Final { get; set; }

    }
}